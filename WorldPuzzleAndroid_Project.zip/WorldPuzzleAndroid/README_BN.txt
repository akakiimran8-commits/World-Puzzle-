World Puzzle Adventure — Android APK project

এই ZIP-এ আপনার index.html গেমটি Android WebView অ্যাপের মধ্যে রাখা হয়েছে।
এখানে তৈরি APK ফাইল নেই; Android IDE দিয়ে বিল্ড করতে হবে।

Android ফোনে বিল্ড করার সাধারণ ধাপ:
1. ZIP-টি Extract করুন।
2. AndroidIDE/সমর্থিত Android IDE ইনস্টল করুন এবং SDK/Gradle build tools সেটআপ করুন।
   নোট: AndroidIDE-এর মূল প্রকল্পটি archived, তাই এটি সব ফোনে কাজ নাও করতে পারে।
3. IDE-তে Extract করা WorldPuzzleAndroid ফোল্ডারটি Open Existing Project হিসেবে খুলুন।
4. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
5. Build/Run বা assembleDebug চালান।
6. সফল হলে IDE APK-এর অবস্থান দেখাবে; সাধারণত app/build/outputs/apk/debug/app-debug.apk।
7. APK ইনস্টল করতে Android-এর “Install unknown apps” অনুমতি প্রয়োজন হতে পারে।

গেমের ছবি Unsplash-এর URL থেকে আসে, তাই ছবির জন্য ইন্টারনেট প্রয়োজন।
এই প্রকল্পে বিজ্ঞাপন যোগ করা হয়নি।
